export default location.origin.indexOf('github.io') !== -1
